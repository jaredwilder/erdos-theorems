# Canonical gold registry

Curated assets: **56**. This registry supersedes all earlier promotion lists.

Status rule: `KERNEL_CHECKED` means the listed theorem scope was previously audited as matching the kernel artifact. `KERNEL_CHECKED_FINITE_ONLY` or notes such as finite/single-instance mean the universal theorem is mathematically audited but **not** universally kernel-certified.

## G001 — #276: Common divisors of Fibonacci/Lucas-type recurrences
**Status:** KERNEL_CHECKED · **Tier:** A · **Lean:** DONE

**Statement.** For every a:ℕ→ℕ satisfying a(n+2)=a(n+1)+a(n), d divides every term iff d | gcd(a0,a1).

**Proof / certificate.** Forward direction uses n=0,1. Reverse direction: gcd divisibility gives d|a0,d|a1; two-step induction and closure of divisibility under addition gives all n.

**Kernel receipt.** `fmz-erdos276-campaign-001-R004-L1.cable.json`

**Formal scope.** matches listed theorem scope per prior audit

**Notes.** Axiom footprint {Quot.sound, propext}.

## G002 — #Sidon-8: No 5-element Sidon subset of Fin 8
**Status:** KERNEL_CHECKED · **Tier:** A · **Lean:** DONE

**Statement.** Every 5-element S⊂Fin 8 has a nontrivial equal pair-sum; together with a 4-element witness this certifies the finite optimum f(8)=4 under the campaign convention.

**Proof / certificate.** Kernel exhaustive decide over all 5-subsets.

**Kernel receipt.** `run19-close-sidon8-k5.cable.json`

**Formal scope.** matches listed theorem scope per prior audit

**Notes.** Axiom footprint {Classical.choice, Quot.sound, propext}.

## G003 — #400: Factorial-divisibility logarithmic bound
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For fixed k≥2, g_k(n) ≤ k(⌊log₂ n⌋+1), hence g_k(n)=O_k(log n) and Σ_{n≤x}g_k(n)=O_k(x log x). Also g_k(m!)≥m+k−3.

**Proof / certificate.** If ∏a_i! | n!, Legendre at 2 gives Σ(a_i−s₂(a_i))≤n−s₂(n); rearrange and bound each binary digit sum by ⌊log₂n⌋+1. Lower family at N=m!: (N−1,m,1,…,1), because (N−1)!m!=N!.

**Formal scope.** not kernel-certified at universal scope

**Notes.** New third-pass gold.

## G004 — #1142: Multiplicative-order modular sieve
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** Let Good(n) mean n−2^j is prime for every 1<2^j<n. For odd prime p, r=ord_p(2): if n>p+2^r and n mod p∈<2>, Good(n) is impossible. Thus Good(n), n>21 ⇒ 15|n. 105 passes the required differences.

**Proof / certificate.** Choose j∈{1,…,r} with 2^j≡n mod p. Then n−2^j>p and divisible by p. For p=3,5, 2 is primitive, forcing p|n above the thresholds.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Recovered from overlooked campaign transcript seam.

## G005 — #1052: Two-prime-factor unitary perfect classification
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** No odd unitary-perfect n>1 exists; among unitary-perfect numbers with at most two distinct prime factors, the only one is 6.

**Proof / certificate.** σ*(n)=∏(p^a+1)=2n. Odd n gives too much 2-adic valuation. For n=2^a q^b, rearrange to q^b(2^a−1)=2^a+1, hence 2^a−1|2, so a=1 and q^b=3.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Elementary.

## G006 — #247: Sparse binary-position irrationality
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P2

**Statement.** If a_n is strictly increasing and limsup a_n/n=∞, then Σ 2^(−a_n) is irrational.

**Proof / certificate.** The binary expansion has 1-positions exactly a_n. A rational binary expansion is eventually periodic. An infinite eventually periodic set of 1-positions has positive density and therefore a_n=O(n), contradiction. Handle the two binary expansions by noting infinitely many 0s and 1s.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Needs careful real-series/binary-expansion formalization.

## G007 — #826: Divisor-bound tail elimination
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** For k>√n, τ(n+k)<3k. Therefore any Ck bound proved for k≤√n extends globally with constant max(C,3).

**Proof / certificate.** τ(m)≤2√m; n<k² gives n+k<k²+k≤2k², so τ(n+k)<2√2 k<3k.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Elementary.

## G008 — #1061: No diagonal sigma solutions
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** σ(a)+σ(a)=σ(2a) has no positive solution. Hence all solutions to σ(a)+σ(b)=σ(a+b) are off-diagonal, so ordered and unordered counts differ exactly by factor 2.

**Proof / certificate.** Write a=2^e m with m odd. Multiplicativity gives σ(2a)/σ(a)=(2^(e+2)−1)/(2^(e+1)−1)>2.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Elementary.

## G009 — #1073: Factorial-plus-one divisor shape
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** If u>1 and u | n!+1, then every prime p|u satisfies p>n; if u is composite then u>n².

**Proof / certificate.** If p≤n then p|n!, contradicting p|n!+1. Composite u has at least two prime factors with multiplicity, each >n.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Does NOT imply the campaign’s claimed O(√x) count or prime-power Wilson close.

## G010 — #936: Powerful-number square-cube congruence restriction
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** C · **Lean:** P1

**Statement.** Every odd powerful m=a²b³ with b squarefree. For n≥3, if 2^n−1 is powerful then b≡7 (mod 8); if 2^n+1 is powerful then b≡1 (mod 8).

**Proof / certificate.** Collect prime exponents e≥2 as e=2q+3r with r∈{0,1}; squarefree b collects the r=1 primes. Since a²≡1 mod8 for odd a and b³≡b mod8, b≡m mod8.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Also applies to n!±1 for n≥4.

## G011 — #477: Square-value tiling slice obstruction
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For B={k²:k≥0}, there is no finite A⊂ℤ with unique representation ℤ=A+B.

**Proof / certificate.** Differences of squares are exactly integers not ≡2 mod4. Uniqueness forces every nonzero A-difference ≡2 mod4. Three A-elements contradict closure of differences; so |A|≤2. Finite A+B is bounded below and cannot cover ℤ.

**Formal scope.** not kernel-certified at universal scope

**Notes.** v2 gold.

## G012 — #700: Exact semiprime binomial gcd formula
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For primes p≤q and n=pq, f(n)=p for the campaign’s f(n)=min_{1<k≤n/2} gcd(n,C(n,k)).

**Proof / certificate.** Lucas modulo p,q forces every admissible gcd to contain p or q as needed; k=q gives exact p for p<q. For p=q, Kummer gives v_p(C(p²,p))=1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Corrects poisoned ledger values such as f(21)=7; exact is 3.

## G013 — #479: Infinite k-family for n | 2^n−k
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For j≥0 and every odd prime p, k=2^(2^j), n=2^j p satisfies 2^n≡k (mod n). Hence each such k has infinitely many witnesses.

**Proof / certificate.** Modulo p, Fermat gives 2^(2^j p)≡2^(2^j). Modulo 2^j both sides vanish; use CRT.

**Formal scope.** not kernel-certified at universal scope

**Notes.** v2 gold.

## G014 — #885: Factor-difference square criterion
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For N≥1,d≥0: d is a factor difference |a−b| with ab=N iff d²+4N is a square.

**Proof / certificate.** Forward: d²+4ab=(a+b)². Reverse: if s²=d²+4N, parity gives integers a=(s+d)/2,b=(s−d)/2 with ab=N.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Full-problem LCM construction in ledger is false; this equivalence survives.

## G015 — #456: Prime-index equality family
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For every prime p, at n=p−1 the two quantities satisfy m_n=p_n=p (under campaign definitions).

**Proof / certificate.** p≡1 mod p−1. If m<p then φ(m)≤m−1≤p−2, so p−1∤φ(m). Thus p is minimal on the totient side too.

**Formal scope.** not kernel-certified at universal scope

**Notes.** v2 gold.

## G016 — #289: Unique maximal 2-adic denominator barrier
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** Every reciprocal sum over a nontrivial consecutive integer interval is nonintegral. More generally, in an integral sum of interval-block reciprocal sums, the number of blocks attaining the global maximal denominator v₂ must be even.

**Proof / certificate.** Each interval has a unique denominator with maximal v₂. After scaling by the global LCM, parity is determined exactly by the blocks whose maximal v₂ equals the global maximum.

**Formal scope.** not kernel-certified at universal scope

**Notes.** v2 gold.

## G017 — #243: Eventual divisibility irrationality barrier
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P2

**Statement.** If eventually a_n|a_(n+1) and a_(n+1)/a_n→∞, then Σ1/a_n is irrational.

**Proof / certificate.** Assume rational P/Q. Multiply by a_m: prefix integral, tail T_m>0. Divisibility gives T_m→0 (eventually ≤2/b_m). But the nonzero fractional part of a rational with denominator Q is ≥1/Q, contradiction.

**Formal scope.** not kernel-certified at universal scope

**Notes.** v2 gold.

## G018 — #985: 3 primitive modulo Fermat-prime subfamily
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** C · **Lean:** P1

**Statement.** For every Fermat prime p≥5, 3 is a primitive root modulo p.

**Proof / certificate.** Fermat prime p≥5 has p≡5 mod12, so (3/p)=−1. Euler gives 3^((p−1)/2)≡−1; since p−1 is a power of 2, the order must be p−1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Does not classify arbitrary primes.

## G019 — #274: Infinite-group reduction for distinct-cardinality exact coset covers
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** C · **Lean:** P1

**Statement.** Any nontrivial finite exact coset cover with pairwise-distinct part cardinalities cannot live in an infinite group; any >1-part counterexample must be finite.

**Proof / certificate.** A finite union of subsets of cardinal <|G| has cardinal <|G|, so one coset must have size |G|. If its subgroup is proper, a disjoint coset of the same cardinal lies in the complement, impossible.

**Formal scope.** not kernel-certified at universal scope

**Notes.** v2 gold.

## G020 — #C(13,6,3): Degree lower bound for hypothetical 20-block cover
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** In any 20-block 6-uniform cover of all triples on 13 points, every pair occurs in at least 3 blocks, every point has degree at least 8, and total degree excess above 8 is exactly 16.

**Proof / certificate.** For fixed pair x,y there are 11 triples and each block through the pair covers 4 third points, so r_xy≥3. Then 5r_x=Σ_{y≠x}r_xy≥36, hence r_x≥8. Total incidence=20·6=120.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Raw-transcript-only gold.

## G021 — #1085: One-dimensional exact unit-distance extremum
**Status:** MATHEMATICALLY_AUDITED · **Tier:** C · **Lean:** P2

**Statement.** In dimension 1, f_1(n)=n−1 for n≥1.

**Proof / certificate.** The unit-distance graph on points of the line is a forest/path union, giving at most n−1 edges; an arithmetic progression with spacing 1 attains n−1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Elementary known subcase.

## G022 — #376: Kummer no-carry criterion for gcd(C(2n,n),105)
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** gcd(C(2n,n),105)=1 iff doubling n has no carries in bases 3,5,7; equivalently every base-3 digit is <=1, every base-5 digit <=2, and every base-7 digit <=3.

**Proof / certificate.** Kummer: v_p(C(2n,n)) is the number of carries in n+n base p. No carry at a digit d iff 2d<p. Apply p=3,5,7.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Residual infinitude remains open.

## G023 — #681: Witness geometry and finite search window
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For k=1, the witness condition holds iff n+1 is composite. Every witness k satisfies k^4<n+k.

**Proof / certificate.** If m=n+k is composite, its least prime factor p(m)<=sqrt(m). The witness k^2<p(m) therefore gives k^4<m=n+k. For k=1, composite m has p(m)>1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Only shifted primes n+1 can be hard at k=1.

## G024 — #238: Complete c2<2 parameter slice
**Status:** MATHEMATICALLY_AUDITED_CITATION_DEPENDENT · **Tier:** C · **Lean:** P2

**Statement.** For every fixed c1>0 and 0<c2<2, the requested prime block exists for all sufficiently large x.

**Proof / certificate.** Distinct odd primes differ by at least 2, so every pair in the block satisfies the separation. Standard prime-counting growth gives more than c1 log x primes eventually.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Uses standard prime-counting growth; not a full solution for arbitrary c2.

## G025 — #821: Odd totient targets have no preimages
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For every odd n>1, g(n)=0 where g(n)=#{m:phi(m)=n}.

**Proof / certificate.** For m>=3, units pair fixed-point-freely under a -> -a, so phi(m) is even; phi(1)=phi(2)=1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Strong domain filter, not a close.

## G026 — #936-mod9: Exact mod-9 periodicity for 2^n+1
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** 9 divides 2^n+1 iff n≡3 mod 6.

**Proof / certificate.** Powers of 2 modulo 9 have period 6: 2,4,8,7,5,1; only exponent 3 gives -1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Complements the powerful-number restriction already in registry.

## G027 — #413: Exact O(log n) finite-window reduction
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For n>1, [forall m<n, m+omega(m)<=n] iff omega(n-1)<=1 and omega(n-k)<=k for 2<=k<=ceil(log2(n-1)); all larger k are automatic.

**Proof / certificate.** Put m=n-k. Since 2^omega(t)<=rad(t)<=t, omega(t)<=log2 t. Thus k>ceil(log2(n-1)) cannot violate. The k=1 clause is omega(n-1)<=1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Turns a length-n universal check into O(log n) exact checks.

## G028 — #406: 3-adic exponent sieve for ternary {0,1} powers
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** If the ternary digits of 2^n are all 0/1 then n mod 18 is in {0,2,6,8}. More generally modulo 3^r the allowed exponents form exactly 2^(r-1) classes modulo 2*3^(r-1).

**Proof / certificate.** Modulo 3^r the residue must be a Cantor residue sum eps_j 3^j. Exactly half are units. Since 2 is a primitive root mod 3^r, each unit residue corresponds to one exponent class. For r=3 the classes are 0,2,6,8 mod18.

**Formal scope.** not kernel-certified at universal scope

**Notes.** The Senge-Straus close is blacklisted; this sieve survives.

## G029 — #683: Necessary ceiling on the universal exponent c
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** Any constant c satisfying the canonical binomial largest-prime-factor inequality must obey c<=log_3(5/3).

**Proof / certificate.** At (n,k)=(10,3), C(10,3)=120 has largest prime factor 5 and n-k+1=8, hence 5>=min(8,3^(1+c)); therefore 3^(1+c)<=5.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Interior parameter; separate P(1) endpoint defect remains.

## G030 — #913: Exact omega=2 stratum classification
**Status:** MATHEMATICALLY_AUDITED_CITATION_DEPENDENT · **Tier:** C · **Lean:** P2

**Statement.** If omega(n(n+1))=2 and the two nonzero prime exponents are distinct, then n is 8, a Fermat-prime predecessor 2^a with 2^a+1 prime, or a Mersenne prime 2^b-1.

**Proof / certificate.** Coprimality forces n,n+1 to be prime powers. If both exponents >=2, Catalan/Mihailescu gives 8,9. If one exponent is 1, parity forces the other factor to be a power of 2, yielding Fermat or Mersenne branches.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Corrects raw route that omitted the Mersenne branch.

## G031 — #1212: Infinite family of admissible dead ends
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For every k>=2, v_k=(2,3^k) is a graph vertex of degree 1, and its unique neighbor (1,3^k) is outside the admissible min>1 subgraph.

**Proof / certificate.** The four coordinate-step candidates are (1,3^k),(3,3^k),(2,3^k-1),(2,3^k+1). Only the first is coprime.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Does not rule out a different infinite component.

## G032 — #145: Squarefree-gap moments for 0<=alpha<=1
**Status:** MATHEMATICALLY_AUDITED_CITATION_DEPENDENT · **Tier:** C · **Lean:** P2

**Statement.** For every fixed 0<=alpha<=1, the normalized squarefree-gap alpha-moment has a finite limit; at alpha=1 the limit is 1.

**Proof / certificate.** For each fixed gap g, standard finite squarefree-pattern correlation theory gives a density. For alpha<1, truncate at G and bound the tail by G^(alpha-1) times the telescoping total gap sum = x+o(x). At alpha=1 telescope directly.

**Formal scope.** not kernel-certified at universal scope

**Notes.** This survives. The separate row claiming all gaps <=4 and hence all alpha is false and blacklisted.

## G033 — #486: Finite-A periodicity for the avoidance set
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** For finite A and L=lcm(A), the set B of positive integers divisible by no a in A is eventually periodic mod L; natural and logarithmic densities exist and are equal.

**Proof / certificate.** Once m>max A all exclusions are active, and membership depends only on residues modulo each a, hence modulo L. Periodic sets have the stated densities.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Restricted to finite A.

## G034 — #539: Exact value h(2)=2
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For the quotient-set extremal function in #539, h(2)=2.

**Proof / certificate.** For A={a,b}, g=gcd(a,b), the quotient set is {1,a/g,b/g}, hence size 2 or 3. If one divides the other, e.g. {1,2}, the size is 2.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Exact base case.

## G035 — #168: Two-thirds construction for avoiding {n,2n,3n}
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** F(N)>=ceil(2N/3).

**Proof / certificate.** Take all integers <=N not divisible by 3. Any triple {n,2n,3n} contains 3n, which is excluded.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Lower construction only.

## G036 — #120: All unbounded A are an easy positive-measure subcase
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** If A is unbounded, E=[0,1] has positive measure and contains no affine copy aA+b with a!=0.

**Proof / certificate.** Every nondegenerate affine image of an unbounded set is unbounded, whereas [0,1] is bounded.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Only bounded infinite A remain hard.

## G037 — #503: Exact one-dimensional answer
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** In R, the largest set for which every three points determine an isosceles triangle has size exactly 3.

**Proof / certificate.** Three equally spaced points work. If x1<x2<x3<x4 all triples work, triples 123 and 124 force x1+x3=2x2=x1+x4, hence x3=x4, contradiction.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Exact dimensional slice.

## G038 — #849: Exact t=1 and t=2 binomial slices
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** a=3 has exactly one admissible representation C(n,k)=a; a=10 has exactly two.

**Proof / certificate.** For 3, only C(3,1)=3 and k>=2 starts at 6. For 10, C(10,1)=10 and C(5,2)=10; k>=3 starts at C(6,3)=20.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Base cases for representation multiplicity problem.

## G039 — #241: Exact elementary counting bound
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** If |A|=m and all 3-multiset sums are distinct, then C(m+2,3)<=3N-2; in particular m^3<18N.

**Proof / certificate.** There are C(m+2,3) unordered-with-repetition triples, all giving distinct integer sums in [3,3N], which contains 3N-2 integers.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Rows claiming constants 9 or 6 from the same argument are blacklisted.

## G040 — #930: r=2 threshold obstruction
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** Any k valid for r=2 must satisfy k>=4.

**Proof / certificate.** The disjoint length-3 intervals {1,2,3} and {48,49,50} have product 705600=840^2, a perfect power.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Exact obstruction.

## G041 — #385: Parity baseline and reduction to even n
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** F(n)>=n for every n>=5, and F(n)>n automatically for every odd n>=5. Thus the first question reduces to even n.

**Proof / certificate.** For odd n choose m=n-1: even composite with least prime factor 2 gives m+p(m)=n+1. For even n>=6 choose m=n-2, giving n.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Does not address divergence F(n)-n.

## G042 — #341: Exact seed A={1}: all odd integers
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** Starting the #341 greedy pair-sum sequence from A={1} yields 1,3,5,7,... and constant gap 2.

**Proof / certificate.** If current set is the first m odd numbers, its pair sums are every even integer from 2 through 4m-2. The least integer above 2m-1 not represented is 2m+1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Exact seed behavior.

## G043 — #579: Common-neighborhood K_{2,2} reduction
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** In a K_{2,2,2}-free graph, the common neighborhood of any two vertices is K_{2,2}-free.

**Proof / certificate.** A K_{2,2} inside N(u)∩N(v), together with {u,v}, is a K_{2,2,2}; adjacency uv is irrelevant for non-induced containment.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Structural reduction only.

## G044 — #291: Correct leading-base-p harmonic criterion
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** Let p<=n be prime, let p^e be the largest power of p <=n, and q=floor(n/p^e). For a_n=sum_{k<=n} L_n/k, p divides gcd(a_n,L_n) iff the reduced numerator of H_q is 0 mod p.

**Proof / certificate.** Modulo p, every term L_n/k vanishes unless v_p(k)=e, i.e. k=j p^e with 1<=j<=q<p. The survivors equal a nonzero common factor times sum_{j<=q} j^{-1} mod p.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Corrects corrupted ledger criterion using floor(n/p); that version fails e.g. n=18,p=3.

## G045 — #377: Corrected large-prime Kummer interval criterion
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For prime p<=n with p>sqrt(2n), k=floor(n/p): p does not divide C(2n,n) iff p>2n/(2k+1).

**Proof / certificate.** Since 2n<p^2, n has at most two base-p digits. Kummer says p divides exactly when doubling n causes a carry. Writing n=kp+r, no carry is 2r<p, equivalent to 2n<(2k+1)p.

**Formal scope.** not kernel-certified at universal scope

**Notes.** The unrestricted ledger statement omitted p>sqrt(2n) and is false.

## G046 — #394: Exact prime slice t_2(p)=p-1
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For every odd prime p, t_2(p)=p-1.

**Proof / certificate.** For 1<=m<=p-2 neither m nor m+1 is divisible by p, so p does not divide m(m+1). At m=p-1 the product (p-1)p is divisible by p.

**Kernel receipt.** `fmz-erdos394-campaign-001-R001-L1.cable.json`

**Formal scope.** KERNEL_CHECKED_FINITE_ONLY

**Notes.** The existing green receipt checks primes below 100 only; it does not certify the universal theorem.

## G047 — #727: Infinite k=2 obstruction family
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For every prime p>=7, with k=2 and n=2p-2, (n+2)!^2 does not divide (2n)!.

**Proof / certificate.** Legendre gives v_p((4p-4)!)=3 while 2*v_p((2p)!)=4, so divisibility fails.

**Kernel receipt.** `fmz-erdos727-campaign-001-R001-L1.cable.json`

**Formal scope.** KERNEL_CHECKED_FINITE_ONLY

**Notes.** The green receipt checks eight concrete primes only.

## G048 — #887: Explicit two-nearby-divisor family
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** For n=m(m-1)(m+1)(m+2), m>=2, the divisors m^2+m and m^2+2m both lie in (sqrt(n), sqrt(n)+2 n^(1/4)).

**Proof / certificate.** Both divide n. Squaring shows both exceed sqrt(n). Elementary comparison of their excess over sqrt(n), or (d-sqrt n)=(d^2-n)/(d+sqrt n), bounds each excess by 2 n^(1/4).

**Formal scope.** not kernel-certified at universal scope

**Notes.** Useful lower-structure family; not a refutation of a universal K.

## G049 — #359: Universal quadratic upper bound for the true greedy sequence
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For the n=1 greedy consecutive-block-sum sequence, a_{k+1}<=k(k+1)/2+1.

**Proof / certificate.** Among k earlier terms there are at most k(k+1)/2 contiguous blocks and hence at most that many represented positive integers. Therefore the least missing positive integer is at most one larger.

**Formal scope.** MISLEADING_RECEIPT_QUARANTINED

**Notes.** The existing green receipt defines a2:=5 and is semantically quarantined; the true sequence begins 1,2,4,5,8,10,....

## G050 — #153: Universal Sidon sumset bookkeeping and gap inequality
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For finite Sidon A with |A|=n and A+A={s_1<...<s_t}, t=n(n+1)/2 and (s_t-s_1)^2 <= (t-1) sum_{i<t}(s_{i+1}-s_i)^2.

**Proof / certificate.** Sidon uniqueness gives one sum for each unordered pair with repetition. The second inequality is Cauchy-Schwarz applied to the t-1 positive gaps whose sum is s_t-s_1.

**Kernel receipt.** `fmz-erdos153-campaign-001-R001-L1.cable.json`

**Formal scope.** KERNEL_CHECKED_SINGLE_INSTANCE_ONLY

**Notes.** The green receipt checks only A={1,2,4,8}; universal theorem still needs formalization.

## G051 — #51: Elementary totient-preimage size bound
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** If phi(n)=a and r=omega(n), then r!<=a and n/a<=2^r. Hence n<=a*2^{R(a)}, where R(a)=max{r:r!<=a}.

**Proof / certificate.** phi(n)=n product_{p|n}(1-1/p), so n/a=product p/(p-1)<=2^r. Also a=phi(n)>=product_{i=1}^r(p_i-1)>=r! because the i-th distinct prime is at least i+1.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Applies to every preimage, hence also the least preimage n_a. Does not settle the canonical existence question.

## G052 — #313: Finiteness for every fixed number k of primes
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P1

**Statement.** For each fixed k, the equation sum_{i=1}^k 1/p_i = 1-1/m with distinct primes has only finitely many solutions. Any infinite family must have k unbounded.

**Proof / certificate.** Let P=product p_i. Multiplying by P shows m|P; reducing the cleared equation mod each p_i shows p_i|m, hence m=P. Thus sum 1/p_i+1/P=1. Bound p_1<=k+1. After fixing p_1,...,p_j, residual R_j>0 satisfies R_j<= (k-j+1)/p_{j+1}, so p_{j+1}<=(k-j+1)/R_j; finite branching.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Strengthens the raw fixed-k recursion into an explicit proof.

## G053 — #371: Largest-prime-factor ties are impossible
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For every n>=2, P(n) != P(n+1).

**Proof / certificate.** If the same prime p were the largest prime factor of both, then p would divide gcd(n,n+1)=1, impossible.

**Formal scope.** not kernel-certified at universal scope

**Notes.** The density-1/2 statement remains open.

## G054 — #412: Sigma orbits are strictly increasing above 1
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For every n>=2, sigma(n)>=n+1>n; hence every forward sigma-orbit starting at n>=2 is strictly increasing and has no repetitions.

**Proof / certificate.** 1 and n are distinct positive divisors of n, so sigma(n)>=1+n. Iterate.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Does not prove intersections between different orbits.

## G055 — #655: Regular polygons refute the literal frozen distance bound
**Status:** MATHEMATICALLY_CLOSED_NEGATIVE_LITERAL · **Tier:** A · **Lean:** P0

**Statement.** For every n>=3, the regular n-gon satisfies the circle condition and determines exactly floor(n/2) distinct distances. Therefore no c>0 can make the frozen lower bound (1+c)n/2 hold for all sufficiently large n.

**Proof / certificate.** From a fixed vertex, a chord length is determined by cyclic separation j and occurs for at most the two vertices at separations j and n-j; hence no centered circle contains three other vertices. Chord lengths for j=1,...,floor(n/2) are distinct, giving exactly floor(n/2) distances.

**Kernel receipt.** `erdos655-campaign-001-R001-close.cable.json`

**Formal scope.** KERNEL_CHECKED_FINITE_ONLY

**Notes.** The receipt checks only check(120)=true; the universal negative close is mathematical, not kernel-certified at universal scope.

## G056 — #68: Exact geometric-series reformulation
**Status:** MATHEMATICALLY_AUDITED_LEAN_READY · **Tier:** B · **Lean:** P0

**Statement.** For n>=2, 1/(n!-1)=sum_{j>=1}(n!)^{-j}; the finite truncation has exact positive geometric remainder.

**Proof / certificate.** Apply 1/(x-1)=x^{-1}/(1-x^{-1}) for x=n!>1 and the geometric series formula.

**Formal scope.** not kernel-certified at universal scope

**Notes.** Reformulation only; irrationality remains open.
